#ifndef TYPE_H
#define TYPE_H

enum dmic_rate {
	DMIC_RATE_8000 = 8000,
	DMIC_RATE_16000 = 16000,
	DMIC_RATE_48000 = 48000,
};
#endif

