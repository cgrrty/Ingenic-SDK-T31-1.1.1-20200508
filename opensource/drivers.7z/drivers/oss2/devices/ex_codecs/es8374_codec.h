#ifndef _ES8374_CODEC_H
#define _ES8374_CODEC_H

int es8374_i2c_drv_init(void);
void es8374_i2c_drv_exit(void);

int jz_es8374_init(void);
void jz_es8374_exit(void);

#endif
