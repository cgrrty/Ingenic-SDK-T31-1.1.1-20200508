#include <stdlib.h>
#include <stdio.h>
int main()
{
	int i=1;
	int num=0;
	while(1){
		if (i==1){
			continue;
		}
	num++;
	printf("num=%d",num);
	}
	printf("hhh\n");
}
