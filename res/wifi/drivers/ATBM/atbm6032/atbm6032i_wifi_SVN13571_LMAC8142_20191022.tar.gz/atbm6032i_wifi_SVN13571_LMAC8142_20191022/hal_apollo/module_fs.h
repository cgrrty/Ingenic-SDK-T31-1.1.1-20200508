#ifndef __MODULE_FS_H__
#define __MODULE_FS_H__
extern int atbm_module_attribute_init(void);
extern void atbm_module_attribute_exit(void);
#endif
